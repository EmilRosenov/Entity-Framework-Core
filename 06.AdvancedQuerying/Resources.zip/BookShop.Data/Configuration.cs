﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=DESKTOP-CJ8SP6C\MSSQLSERVER03;Database=BookShop;Integrated Security=True;";
    }
}
