﻿namespace BookShop
{
    using BookShop.Models;
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);


            //int lengthCheck = int.Parse(Console.ReadLine());
           
            var result = RemoveBooks(db);
            Console.WriteLine(result); 
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {

            AgeRestriction ageRestriction;
            bool parseSuccess = Enum.TryParse<AgeRestriction>(command, true, out ageRestriction);

            if (!parseSuccess)
            {
                return "";
            }

            var ageRestrictedBooks = context
                                    .Books
                                    .Where(x => x.AgeRestriction == ageRestriction)
                                    .OrderBy(x => x.Title)
                                    .Select(x => x.Title)
                                    .ToList();



            return String.Join(Environment.NewLine,ageRestrictedBooks);
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            EditionType editionType;
            bool isSuccess = Enum.TryParse<EditionType>("Gold", true, out editionType);

            if (!isSuccess)
            {
                return "";
            }

            var goldenBooks = context.Books
                                     .Where(x => x.EditionType == editionType && x.Copies < 5000)
                                     .OrderBy(x => x.BookId)
                                     .Select(x => new {x.Title})
                                     .ToList();

            var sb = new StringBuilder();
            foreach (var book in goldenBooks)
            {
               sb.AppendLine(book.Title);
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetBooksByPrice(BookShopContext context)
        {

            var booksWithPriceOver40 = context.Books
                                              .Where(b => b.Price > 40)
                                              .Select(b => new
                                              {
                                                  b.Title,
                                                  b.Price
                                              }).OrderByDescending(b => b.Price).ToList();

            var sb = new StringBuilder();
            foreach (var item in booksWithPriceOver40)
            {
                sb.AppendLine($"{item.Title} - ${item.Price:f2}");
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {

            var booksNOTReleasedInYear = context.Books.Where(b => (int)b.ReleaseDate.Value.Year != year)
                                                      .OrderBy(b=>b.BookId)
                                                      .Select(b=>b.Title)
                                                      .ToList();
            return $"{String.Join(Environment.NewLine, booksNOTReleasedInYear)}";
        }

        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            var givenCategories = input.Split(" ", StringSplitOptions.RemoveEmptyEntries)
                                        .Select(x=>x.ToLower())
                                        .ToArray();

            var booksByCategory = context.Books.Include(x => x.BookCategories)
                                               .ThenInclude(x => x.Category)
                                                .Where(x => x.BookCategories.Any(c => givenCategories.Contains(c.Category.Name.ToLower())))
                                                .OrderBy(x => x.Title)
                                                .Select(x => x.Title)
                                                .ToList();
                                               
                                               
            return $"{String.Join(Environment.NewLine,booksByCategory)}";
        }

        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            var splitted = date.Split("-", StringSplitOptions.RemoveEmptyEntries).ToArray();
            var targetDate = DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture);

            var booksReleasedBeforeInputDate = context.Books.Where(x => x.ReleaseDate.Value < targetDate)
                                                                    .OrderByDescending(x => x.ReleaseDate.Value.Year)
                                                                    .ThenByDescending(x => x.ReleaseDate.Value.Month)
                                                                    .ThenByDescending(x => x.ReleaseDate.Value.Date)
                                                                    .Select(x => new
                                                                    {
                                                                        x.Title,
                                                                        x.EditionType,
                                                                        x.Price
                                                                    }).ToList();

            var sb = new StringBuilder();
            foreach (var book in booksReleasedBeforeInputDate)
            {
                sb.AppendLine($"{book.Title} - {book.EditionType} - ${book.Price:f2}");
            }
            return sb.ToString().TrimEnd();
        }


        //only 75 pts
        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {

            var authorsFirstNameEndingToInput = context.Authors.Where(x => x.FirstName.EndsWith(input.ToLower()))
                                                                    .ToList()
                                                                    .OrderBy(x => x.FirstName)
                                                                    .Select(x => new
                                                                    {
                                                                        FullName = $"{x.FirstName} {x.LastName}"
                                                                    }).ToList();
            
            if (authorsFirstNameEndingToInput.Count == 0)
            {
                return String.Empty;
            }
            
            var sb = new StringBuilder();
            foreach (var author in authorsFirstNameEndingToInput)
            {
                sb.AppendLine($"{author.FullName}");
            }
            return sb.ToString().TrimEnd();
        }

        // 100 pts
        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {
            
            var titlesContainingInput = context.Books.Where(x => x.Title.ToLower().Contains(input.ToLower()))
                                                    .OrderBy(x => x.Title)
                                                    .Select(x => x.Title)
                                                    .ToList();
            var sb = new StringBuilder();
            foreach (var book in titlesContainingInput)
            {
                sb.AppendLine($"{book}");
            }
            return sb.ToString().TrimEnd();
            
        }


        public static string GetBooksByAuthor(BookShopContext context, string input)
        {
            var booksByAuthor = context.Books
                                       //.Include(a=>a.Author)
                                       .Where(b => b.Author.LastName.ToLower().StartsWith(input.ToLower()))
                                       .OrderBy(b => b.BookId)
                                       .Select(x => new
                                       {
                                           x.Title,
                                          AuthorsFirstName =  x.Author.FirstName,
                                          AuthorsLastName = x.Author.LastName
                                       }).ToList();
            var sb = new StringBuilder();
            foreach (var book in booksByAuthor)
            {
                sb.AppendLine($"{book.Title} ({book.AuthorsFirstName} {book.AuthorsLastName})");
            }
            return sb.ToString().TrimEnd();
        }

        public static int CountBooks(BookShopContext context, int lengthCheck)
        {
            var countBooks = context.Books.Where(x => x.Title.Length > lengthCheck).ToList();
            return countBooks.Count;
        }

        public static string CountCopiesByAuthor(BookShopContext context)
        {

            var authorsAndCopies = context.Authors
                                          .Select(a => new
                                          {
                                              First = a.FirstName,
                                              Second = a.LastName,
                                              Total = a.Books.Sum(b => b.Copies)
                                          })
                                          .OrderByDescending(t => t.Total)
                                          .ToArray();
                                        
            var result = string.Join(Environment.NewLine, authorsAndCopies
                           .Select(autor => $"{autor.First} {autor.Second} - {autor.Total}"));

            return result;
        }

        public static string GetTotalProfitByCategory(BookShopContext context)
        {
            var profitByCategory = context.Categories
                                          //.Include(x=>x.CategoryBooks)
                                          //.ThenInclude(x => x.Category)
                                          //
                                          .Select(x => new
                                          {

                                              CatName  = x.Name,
                                              //CategoriesCount = x.CategoryBooks.Count,
                                              Total = x.CategoryBooks.Sum(x => x.Book.Price * x.Book.Copies)
                                          })
                                            .OrderByDescending(x => x.Total)
                                            .ThenBy(x => x.CatName)
                                            .ToList();

            int category = 1;
            var sb = new StringBuilder();
            foreach (var item in profitByCategory)
            {
                sb.AppendLine($"{item.CatName} ${item.Total:F2}"); // , {category++}/{profitByCategory.Count()}");
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetMostRecentBooks(BookShopContext context)
        {
            var categories = context.Categories
                //.Include(x => x.CategoryBooks).ThenInclude(x => x.Book)
                .Select(x => new
                {
                    CategoryName = x.Name,
                    BooksInCategory = x.CategoryBooks.Select(b => new
                    {
                        b.Book.Title,
                        b.Book.ReleaseDate.Value
                }).OrderByDescending(b => b.Value)
                  .Take(3)
                  .ToList()
            }).OrderBy(x => x.CategoryName)
              .ToArray();
              
             

            var sb = new StringBuilder();
            foreach (var category in categories)
            {
                sb.AppendLine($"--{category.CategoryName}");

                foreach (var book in category.BooksInCategory)
                {
                    sb.AppendLine($"{book.Title} ({book.Value.Year})");
                }
            }

            var result = sb.ToString().TrimEnd();
            return result;
        }

        public static void IncreasePrices(BookShopContext context)
        {
            var booksReleasedBefore2010 = context.Books
                                                .Where(x => x.ReleaseDate.Value.Year < 2010)
                                                .ToList();
            //context.Update(booksReleasedBefore2010);
            foreach (var item in booksReleasedBefore2010)
            {
                item.Price += 5;
            }
            context.SaveChanges();


        }

        public static int RemoveBooks(BookShopContext context)
        {
            var booksWithLessThan4200Copies = context.Books
                                                     .Where(x => x.Copies < 4200)
                                                     .ToList();

            int count = booksWithLessThan4200Copies.Count();
            context.RemoveRange(booksWithLessThan4200Copies);
            
            context.SaveChanges();


            return count;
        }


        private static object Any(string[] input)
        {
            throw new NotImplementedException();
        }

        private static object Any(ICollection<BookCategory> bookCategories)
        {
            throw new NotImplementedException();
        }
    }
}
