﻿using System;

namespace P03_FootballBetting
{
    public class Program
    {
       public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
