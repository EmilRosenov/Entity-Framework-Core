﻿namespace P01_StudentSystem.Data.Models
{
    public enum ContentType
    {
        Application=10,
        Pdf=20,
        Zip=30
    }
}