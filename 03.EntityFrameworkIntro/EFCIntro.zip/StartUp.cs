﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SoftUniContext database = new SoftUniContext();
            var result = GetLatestProjects(database);
            Console.WriteLine(result);
        }

        public static string GetEmployeesFullInformation(SoftUniContext database)
        {
            StringBuilder sb = new StringBuilder();
            var employees = database.Employees
                                   .Select(x => new 
                                                  {
                                                  x.EmployeeId,
                                                  x.FirstName,
                                                  x.LastName,
                                                  x.MiddleName,
                                                  x.JobTitle,
                                                  x.Salary
                                                  })
                                   .OrderBy(x=>x.EmployeeId)
                                   .ToList();        

            foreach (var emp in employees)
            {
                sb.AppendLine($"{emp.FirstName} {emp.LastName} {emp.MiddleName} {emp.JobTitle} {emp.Salary:f2}");
            }
            var result  = sb.ToString().TrimEnd();
            return result;
        }

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext database)
        {
            var sb = new StringBuilder();
            var employeesWithOver50000 = database.Employees
                                                .Where(x=>x.Salary>50000)
                                                .Select(x => new{
                                                        x.FirstName,
                                                        x.Salary})
                                                .OrderBy(x=>x.FirstName)
                                                .ToList();
          

            foreach (var person in employeesWithOver50000)
            {
                sb.AppendLine($"{person.FirstName} - {person.Salary:f2}");
            }

            var result = sb.ToString().TrimEnd();
            return result;
        }

        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext database)
        {
            var employeesFromResAndDev = database.Employees
                                       .Where(x => x.Department.Name == "Research and Development")
                                       .Select(x => new
                                       {
                                           x.FirstName,
                                           x.LastName,
                                           x.Salary,
                                           DepartmentName = x.Department.Name,
                                       })
                                       .OrderBy(x => x.Salary)
                                       .ThenByDescending(x => x.FirstName)
                                       .ToList();
                                      
            var sb = new StringBuilder();

            foreach (var rAndDEmployee in employeesFromResAndDev)
            {
                sb.AppendLine($"{rAndDEmployee.FirstName} {rAndDEmployee.LastName} from {rAndDEmployee.DepartmentName} - ${rAndDEmployee.Salary:F2}");
            }
            var result = sb.ToString().TrimEnd();
            return result;
        }

        public static string AddNewAddressToEmployee(SoftUniContext database)
        {
            
           
            var nakov = database.Employees.FirstOrDefault(x => x.LastName == "Nakov");
            nakov.Address = new Address
            {
                AddressText = "Vitoshka 15",
                TownId = 4
            };
            database.SaveChanges();

            var employeesByAddress = database.Employees
                                             .Select(x => new
                                             {
                                                 x.Address.AddressText,
                                                 x.Address.AddressId
                                             })
                                             .OrderByDescending(x => x.AddressId)
                                             .Take(10)
                                             .ToList();
                                             
            var sb = new StringBuilder();
            foreach (var item in employeesByAddress)
            {
                sb.AppendLine(item.AddressText);
            }
            var result = sb.ToString().TrimEnd();
            return result;
        }

        public static string GetEmployeesInPeriod(SoftUniContext database)
        {
            var employeesWithManagerAndProjects = database
                                                 .Employees
                                                 .Include(x => x.EmployeesProjects)
                                                 .ThenInclude(x => x.Project)
                                                 .Where(x => x.EmployeesProjects.Any(p => p.Project.StartDate.Year >= 2001 && p.Project.StartDate.Year <= 2003))
                                                 
                                                 
                                                 .Select(x => new
                                                 {
                                                     EmployeeFirstName = x.FirstName,
                                                     EmployeeLastName = x.LastName,
                                                     ManagerFirstName = x.Manager.FirstName,
                                                     ManagerLastName = x.Manager.LastName,
                                                     Projects = x.EmployeesProjects.Select(p=> new 
                                                     {
                                                         ProjectName = p.Project.Name,
                                                         ProjectStartDate = p.Project.StartDate,
                                                         ProjectEndDate = p.Project.EndDate
                                                     })

                                                 })
                                                 .Take(10)
                                                 .ToList();
            var sb = new StringBuilder();
            foreach (var emp in employeesWithManagerAndProjects)
            {
                sb.AppendLine($"{emp.EmployeeFirstName} {emp.EmployeeLastName} - Manager: {emp.ManagerFirstName} {emp.ManagerLastName}");

                foreach (var project in emp.Projects)
                {
                    if (project.ProjectEndDate.HasValue)
                    {
                        sb.AppendLine($"--{project.ProjectName} - {project.ProjectStartDate} - {project.ProjectEndDate}");
                    }
                    else
                    {
                        sb.AppendLine($"--{project.ProjectName} - {project.ProjectStartDate} - not finished");
                    }
                    
                }
            }

            var result = sb.ToString().TrimEnd();
            return result;
        }


        public static string GetAddressesByTown(SoftUniContext database)
        {
            var addresses = database.Addresses
                                             
                                             .Select(x => new
                                             {
                                                x.AddressText,
                                                x.Town.Name,
                                                x.Employees.Count
                                             })
                                             .OrderByDescending(x=>x.Count)
                                             .ThenBy(x=>x.Name)
                                             .ThenBy(x=>x.AddressText)
                                             .Take(10)
                                             .ToList();
                                               
                 
            var sb = new StringBuilder();

            foreach (var current in addresses)
            {
                sb.AppendLine($"{current.AddressText}, {current.Name} - {current.Count} employees");
            }

            var result = sb.ToString().TrimEnd();
            return result;
        }


        public static string GetEmployee147(SoftUniContext database)
        {

            var employee147 = database.Employees
                                      .Select(x => new
                                      {
                                          x.EmployeeId,
                                          x.FirstName,
                                          x.LastName,
                                          x.JobTitle,
                                          Project = x.EmployeesProjects.OrderBy(x => x.Project.Name).Select(p => new
                                          {
                                              p.Project.Name
                                          })
                                          
                                      })
                                      .FirstOrDefault(x => x.EmployeeId == 147);
                                      
                                      
                                      
                                      

            var sb = new StringBuilder();

            sb.AppendLine($"{employee147.FirstName} {employee147.LastName} - {employee147.JobTitle}");
            foreach (var proj in employee147.Project)
            {
                sb.AppendLine(proj.Name);
            }

            var result = sb.ToString().TrimEnd();
            return result;
        }

        public static string GetDepartmentsWithMoreThan5Employees(SoftUniContext database)
        {

            var departmentsWithMin5Employees = database.Departments
                                                       .Where(x => x.Employees.Count > 5)
                                                       .OrderBy(x => x.Employees.Count)
                                                       .ThenBy(x => x.Name)
                                                       .Select(x => new
                                                       {
                                                           x.Name,
                                                           x.Manager.FirstName,
                                                           x.Manager.LastName,
                                                           Employees = x.Employees.Select(e => new
                                                           {
                                                               e.FirstName,
                                                               e.LastName,
                                                               e.JobTitle
                                                           })
                                                           .OrderBy(x => x.FirstName)
                                                           .ThenBy(x => x.LastName)
                                                           .ToList()
                                                       })
                                                         .ToList();

            var sb = new StringBuilder();

            foreach (var department in departmentsWithMin5Employees)
            {
                sb.AppendLine($"{department.Name} - {department.FirstName} {department.LastName}");

                foreach (var employees in department.Employees)
                {
                    sb.AppendLine($"{employees.FirstName} {employees.LastName} - {employees.JobTitle}");
                }
            }

            var result = sb.ToString().TrimEnd();
            return result;
        }


        public static string GetLatestProjects(SoftUniContext database)
        {
            var last10StartedProj = database.Projects
                                            .Select(x => new
                                            {
                                                x.Name,
                                                x.Description,
                                                x.StartDate
                                            })
                                              .OrderByDescending(x => x.StartDate.Year)
                                              .ThenByDescending(x=>x.StartDate.Month)
                                              .ThenByDescending(x=>x.StartDate.Day)
                                              .ThenByDescending(x=>x.StartDate.Hour)
                                              .ThenByDescending(x=>x.StartDate.Minute)
                                              .ThenByDescending(x=>x.StartDate.Second)
                                              .Take(10)
                                              .ToList()
                                              .OrderBy(x => x.Name);

            database.SaveChanges();                                
                                              
                                              

            var sb = new StringBuilder();

            foreach (var proj in last10StartedProj)
            {
                sb.AppendLine(proj.Name);
                sb.AppendLine(proj.Description);
                sb.AppendLine(proj.StartDate.ToString("M/d/yyyy h:mm:ss tt"));
            }

            var result = sb.ToString().TrimEnd();
            return result;
        }

        public static string IncreaseSalaries(SoftUniContext database)
        {

            //increase salaries of all employees that are in the Engineering, Tool Design,
            //Marketing or Information Services department by 12 %.
            //Then return first name, last name and salary(2 symbols after the decimal
            //separator) for those employees whose salary was increased.
            // Order them by first name(ascending), then by last name(ascending).
            // Format of the output.

            var employeesInDepartments = database.Employees.
                                         Where(x => x.Department.Name == "Engineering"
                                             || x.Department.Name == "Tool Design"
                                             || x.Department.Name == "Marketing"
                                             || x.Department.Name == "Information Services")
                                           .OrderBy(x => x.FirstName)
                                           .ThenBy(x => x.LastName)
                                           .ToList();

            foreach (var employee in employeesInDepartments)
            {
                employee.Salary *= 1.12m;
            }

            database.SaveChanges();

            var sb = new StringBuilder();

            foreach (var employee in employeesInDepartments)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} (${employee.Salary:f2})");
            }
            

            var result = sb.ToString().TrimEnd();
            return result;
        }

        public static string GetEmployeesByFirstNameStartingWithSa(SoftUniContext database)
        {

            var employeesNameStartingWithSa = database
                                             .Employees
                                             .Where(x => x.FirstName.StartsWith("Sa"))
                                             .Select(x => new
                                             {
                                                 x.FirstName,
                                                 x.LastName,
                                                 x.JobTitle,
                                                 x.Salary
                                             }).OrderBy(x => x.FirstName)
                                               .ThenBy(x => x.LastName)
                                               .ToList();
            var sb = new StringBuilder();

            foreach (var item in employeesNameStartingWithSa)
            {
                sb.AppendLine($"{item.FirstName} {item.LastName} - {item.JobTitle} - (${item.Salary:f2})");
            }

            var result = sb.ToString().TrimEnd();
            return result;
        }

        public static string DeleteProjectById(SoftUniContext database)
        {
            var projectsToDelete = database.Projects.Find(2);

            EmployeeProject[] referredEmployees = database
                                                  .EmployeesProjects
                                                  .Where(ep => ep.ProjectId
                                                       == projectsToDelete.ProjectId)
                                                  .ToArray();

            database.EmployeesProjects.RemoveRange(referredEmployees);
            database.Projects.Remove(projectsToDelete);
            database.SaveChanges();

            string[] projectNames = database
                                    .Projects
                                    .Take(10)
                                    .Select(x =>x.Name)
                                    .ToArray();

            var sb = new StringBuilder();
            foreach (var item in projectNames)
            {
                sb.AppendLine($"{item}");
            }
            var result = sb.ToString().TrimEnd();
            return result;

        }

        public static string RemoveTown(SoftUniContext database)
        {
            var townToRemove = database.Towns
                                       .Include(x => x.Addresses)
                                       .FirstOrDefault(x => x.Name == "Seattle");
            var addressesToMakeNull = townToRemove.Addresses
                                                  .Select(x => x.AddressId)
                                                  .ToList();

            var employees = database.Employees
                                     .Where(x => x.AddressId.HasValue && addressesToMakeNull
                                     .Contains(x.AddressId.Value))
                                     .ToList();

            foreach (var employee in employees)
            {
                employee.AddressId = null;
                
            }

            foreach (var addressId in addressesToMakeNull)
            {
                var address = database.Addresses.FirstOrDefault(x => x.AddressId == addressId);
                database.Addresses.Remove(address);
            }

            database.SaveChanges();
            database.Towns.Remove(townToRemove);
            

            var result = $"{addressesToMakeNull.Count()} addresses in Seattle were deleted";
            return result;
        }
    }
}
