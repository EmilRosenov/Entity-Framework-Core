﻿namespace MiniORM
{
	// TODO: Create your DbSet class here.
}