﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public static class Config
    {
         public static string ConnectionString = @"Server=DESKTOP-CJ8SP6C\MSSQLSERVER03;Database=SoftUni;Integrated Security = true";
    }
}
