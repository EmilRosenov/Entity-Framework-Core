﻿using System;
using System.Data.SqlClient;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using SqlConnection sqlConnection = new SqlConnection(Config.ConnectionString);
            sqlConnection.Open();
            //1. here we have an open connection



            Console.WriteLine("Connection completed!");
            Console.WriteLine("Press any key to continue!");
            //this is just for debugging

            //2. then we need to create a command

            // if we use transaction -> On Add,Delete,Update -> Use transaction
            //SqlTransaction transaction = sqlConnection.BeginTransaction();
            string countQuery = "SELECT COUNT(*) " +
                               "AS [EmployeeCount]" + 
                             "FROM [Employees]";

            SqlCommand command = new SqlCommand(countQuery, sqlConnection);   //,transaction);

            object employeeCount = command.ExecuteScalar();
            Console.WriteLine(employeeCount);
            //ExecuteScalar()
            //ExecuteReader()

            string employeeInfoQuery = @"SELECT [FirstName],
                                                [LastName],
                                    	        [JobTitle]
                                           FROM [Employees]";


            SqlCommand employeeInfoCmd = new SqlCommand(employeeInfoQuery, sqlConnection);
            
            using SqlDataReader employeeInfoReader = employeeInfoCmd.ExecuteReader();

            int num = 1;
            while (employeeInfoReader.Read())
            {
                string firstName = (string)employeeInfoReader["FirstName"];
                string lastName = (string)employeeInfoReader["LastName"];
                string job = (string)employeeInfoReader["JobTitle"];
                Console.WriteLine($"#{num++}. {firstName} {lastName} - {job}");
            }
            employeeInfoReader.Close();
            sqlConnection.Close();
        }
    }
}
