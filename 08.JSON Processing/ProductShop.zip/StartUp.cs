﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.DataTransferObjects;
using ProductShop.Models;
using Microsoft.EntityFrameworkCore;

namespace ProductShop
{
    public class StartUp
    {
        static IMapper mapper; 
        public static void Main(string[] args)
        {
           var productShopContext = new ProductShopContext();
           //productShopContext.Database.EnsureDeleted();
           //productShopContext.Database.EnsureCreated();
           //InitializeAutomapper();
           //
           //string usersJson = File.ReadAllText("../../../Datasets/users.json");
           //string productsJson = File.ReadAllText("../../../Datasets/products.json");
           //string categoryJson = File.ReadAllText("../../../Datasets/categories.json");
           //string categoryProductJson = File.ReadAllText("../../../Datasets/categories-products.json");
           //
           //ImportUsers(productShopContext, usersJson);
           //ImportProducts(productShopContext, productsJson);
           //ImportCategories(productShopContext, categoryJson);
           //ImportCategoryProducts(productShopContext, categoryProductJson);
           
           var result = GetUsersWithProducts(productShopContext);
           Console.WriteLine(result);

        }


        // 01. Import Users


        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            InitializeAutomapper();

            var dtoUsers = JsonConvert.DeserializeObject<DtoUserInputModel[]>(inputJson);
            var users = mapper.Map<User[]>(dtoUsers);

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }



        // 02. Import Products
        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            InitializeAutomapper();

            var dtoProducts = JsonConvert.DeserializeObject<DtoProductsInputModel[]>(inputJson);
            var products = mapper.Map<Product[]>(dtoProducts);

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count()}";
        }

        // 03. Import Categories
        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            InitializeAutomapper();

            var dtoCategories = JsonConvert.DeserializeObject<DtoCategoryInputModel[]>(inputJson);
            var categories = mapper.Map<Category[]>(dtoCategories).Where(x=>x.Name!=null).ToArray();

            context.Categories.AddRange(categories);
            context.SaveChanges();

            return $"Successfully imported {categories.Count()}";
        }

        //Query 4. Import Categories and Products

        public static string ImportCategoryProducts(ProductShopContext context, string inputJson)
        {
            InitializeAutomapper();
            var dtoCatProducts = JsonConvert.DeserializeObject<IEnumerable<DtoCategoriesProductsInputModel>>(inputJson);
            var catProducts = mapper.Map<IEnumerable<CategoryProduct>>(dtoCatProducts);

            context.CategoryProducts.AddRange(catProducts);
            context.SaveChanges();

            return $"Successfully imported {dtoCatProducts.Count()}";
        }


        //Query 5. Export Products in Range
        public static string GetProductsInRange(ProductShopContext context)
        {
            var products = context.Products
                                  .Where(x => x.Price >= 500 && x.Price <= 1000)
                                  .Select(x => new
                                  {
                                      name = x.Name,
                                      price = x.Price,
                                      seller = x.Seller.FirstName + ' ' + x.Seller.LastName
                                  })
                                  .OrderByDescending(x => x.price)
                                  .ToArray();

            var result = JsonConvert.SerializeObject(products,Formatting.Indented) ;
            return result; 
        }

        //Query 6. Export Sold Products
        public static string GetSoldProducts(ProductShopContext context)
        {
            var users = context.Users
                               .Where(x => x.ProductsSold.Any(x => x.BuyerId != null))
                               .Select(u => new
                               {
                                   firstName = u.FirstName,
                                   lastName = u.LastName,
                                   soldProducts = u.ProductsSold
                                                   .Where(p=>p.BuyerId!=null)
                                                   .Select(ps => new
                                                    {
                                                        name = ps.Name,
                                                        price = ps.Price,
                                                        buyerFirstName = ps.Buyer.FirstName,
                                                        buyerLastName = ps.Buyer.LastName
                                                    })
                                                   .ToList()
                               })
                               .OrderBy(x => x.lastName)
                               .ThenBy(x => x.firstName)
                               .ToList();

            var result = JsonConvert.SerializeObject(users,Formatting.Indented);
                                    
            return $"{String.Join(Environment.NewLine, result)}";
        }

        //07. Export Categories By Products Count
        public static string GetCategoriesByProductsCount(ProductShopContext context)
        {
            var categoriesByProdCount = context.Categories
                                               .Select(c => new
                                               {
                                                   category = c.Name,
                                                   productsCount = c.CategoryProducts.Count,
                                                   averagePrice = c.CategoryProducts.Average(p => p.Product.Price).ToString("F2"),
                                                   totalRevenue = c.CategoryProducts.Sum(p => p.Product.Price).ToString("F2")
                                               })
                                                 .OrderByDescending(c=>c.productsCount)
                                                 .ToArray();

            var result = JsonConvert.SerializeObject(categoriesByProdCount, Formatting.Indented);
            return String.Join(Environment.NewLine, result);
        }


        //08. Export Users and Products
        public static string GetUsersWithProducts(ProductShopContext context)
        {
            var usersWithProducts = context.Users
                                           .Include(x=>x.ProductsSold)
                                           .ToList()
                                           .Where(x => x.ProductsSold.Any(y => y.BuyerId != null))
                                           .Select(u => new
                                           {
                                               firstName = u.FirstName,
                                               lastName = u.LastName,
                                               age = u.Age,
                                               soldProducts = new
                                                    {
                                                        count = u.ProductsSold.Where(x => x.BuyerId != null).Count(),
                                                        products = u.ProductsSold
                                                               .Where(x=>x.BuyerId!=null)
                                                               .Select(p => new
                                                                      {
                                                                         name = p.Name,
                                                                         price = p.Price
                                                                       })
                                                    }

                                           })
                                           .OrderByDescending(x=>x.soldProducts.products.Count())
                                           .ToList();
            var resultObject = new
            {
                usersCount = context.Users.Where(x => x.ProductsSold.Any(y => y.BuyerId != null)).Count(),
                users = usersWithProducts
            };

            var jsonSerializerSettings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            };

            var resultJson = JsonConvert.SerializeObject(resultObject, Formatting.Indented, jsonSerializerSettings);
                                           return resultJson;
           //var result = JsonConvert.SerializeObject(usersWithProducts, Formatting.Indented);
           //return $"{string.Join(Environment.NewLine, result)}";
        }


        private static void InitializeAutomapper()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<ProductShopProfile>();
            });

            mapper = config.CreateMapper();
        }
    }
}