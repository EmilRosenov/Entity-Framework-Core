﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Data
{
    internal class Config
    {
        public const string Server = @"Server=DESKTOP-CJ8SP6C\MSSQLSERVER03;Database=ProductShop;Integrated Security=True";

        //public Config(string server)
        //{
        //    this.Server = server;
        //}
        //public string Server { get; set; } 
    }

}
