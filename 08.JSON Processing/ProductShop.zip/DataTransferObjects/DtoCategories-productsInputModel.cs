﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DataTransferObjects
{
    public class DtoCategoriesProductsInputModel
    {
        public int CategoryId { get; set; }
        public int ProductId { get; set; }
    }
}
