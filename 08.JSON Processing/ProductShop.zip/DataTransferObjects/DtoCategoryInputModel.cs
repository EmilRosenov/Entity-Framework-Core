﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DataTransferObjects
{
    public class DtoCategoryInputModel
    {
        public string? Name { get; set; }
    }
}
