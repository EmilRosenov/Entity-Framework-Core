﻿using AutoMapper;
using ProductShop.DataTransferObjects;
using ProductShop.Models;

namespace ProductShop
{
    public class ProductShopProfile : Profile
    {
        public ProductShopProfile()
        {
            this.CreateMap<DtoUserInputModel, User>();
            this.CreateMap<DtoProductsInputModel, Product>();
            this.CreateMap<DtoCategoryInputModel, Category>();
            this.CreateMap<DtoCategoriesProductsInputModel, CategoryProduct>();
        }
    }
}
