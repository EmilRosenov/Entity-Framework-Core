﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.ComponentModel.DataAnnotations.Schema;

namespace MusicHub.Data.Models
{
    public class Album
    {
        //•	Id – integer, Primary Key
        //•	Name – text with max length 40 (required)
        //•	ReleaseDate – date(required)
        //•	Price – calculated property(the sum of all song prices in the album)
        //•	ProducerId – integer, foreign key
        //•	Producer – the album's producer
        //•	Songs – a collection of all Songs in the Album

        public int Id { get; set; }
        
        [Required]
        [MaxLength(40)]
        public string Name { get; set; }
        
        [Required]
        public DateTime ReleaseDate { get; set; }

        public decimal Price => Songs.Sum(x => x.Price);

        [ForeignKey(nameof(Producer))]
        public int? ProducerId { get; set; }

       
        public virtual Producer Producer { get; set; }

        public virtual ICollection<Song>Songs { get; set; }
    }
}
